export enum Role {
  user = 'USER',
  admin = 'ADMIN',
}
